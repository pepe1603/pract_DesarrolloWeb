<table id="tb_consultarAspirantes" class="table table-bordered table-hover">
                  <thead>
                  <tr>
                    <th>Nombre Completo</th>
                    <th>Fecha Nacimiento</th>
                    <th>Edad</th>
                    <th>Escolaridad</th>
                    <th>Promedio</th>>
                    <th>Municipio</th>
                    <th>Certificado</th>
                    <th>Img Cadena</th>
                  </tr>
                  </thead>

                  <tbody>

                  <tr>
                    <td>Trident</td>
                    <td>Internet  Explorer 4.0 </td>
                    <td>Win 95+</td>
                    <td> 4</td>
                    <td>X</td>
                    <td>Ace4rda</td>
                    <td>si</td>
                    <td>place_fixes</td>
                  </tr>        
   <?php                
                
                include('conexion.php');
                $con = conectarbd();
                $cadena_sql = "select namefull, fecha_nac, edad, eschool, promedio, municipio, certificado, foto from t_aspirantes;";

                $res =  mysqli_query($con, $cadena_sql);
                while($fila = mysqli_fetch_row($res)){
                  echo "<tr>";
                 
                 echo " <td>".$fila[0]."</td>";
                 echo " <td>".$fila[1]."</td>";
                 echo " <td>".$fila[2]."</td>";
                 echo " <td>".$fila[3]."</td>";
                 echo " <td>".$fila[4]."</td>";
                 echo " <td>".$fila[5]."</td>";
                 echo " <td>".$fila[6]."</td>";
                 echo " <td>".$fila[7]."</td>";
                echo "</tr>  ";

               

                
                 
                 
                  }
?>                 

                  </tbody>
                 
                </table>
