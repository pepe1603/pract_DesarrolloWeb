<?php
$p_nom = $_GET['txtNombreFull'];
$p_fecha = $_GET['txtFechaNac'];
$p_edad = $_GET['txtEdad'];
$p_escolaridad = $_GET['txtEscolaridad'];
$p_promedio = $_GET['txtPromedio'];
$p_municipio = $_GET['txtMunicipio'];
$p_certificado = $_GET['txtCertificado'];
$p_cfoto = $_GET['txtFoto'];

include('conexion.php');

$con = conectarbd();
//$sql="insert into t_productos values (".$par1.",'".$par2."',".$par3.",'".$par4."')";
$sql = "INSERT INTO t_aspirantes (namefull, fecha_nac, edad, eschool, promedio, municipio, certificado, foto) 
                                VALUES ('.$p_nom.', '.$p_fecha.', '.$p_edad.', '.$p_escolaridad.', '.$p_promedio.', '.$p_municipio.', '$p_certificado', '$p_cfoto');";
//$sql ="insert into td_productos values(".$par1.",'".$par2."',".$par3.",'".$par4.'")";


 
?>
