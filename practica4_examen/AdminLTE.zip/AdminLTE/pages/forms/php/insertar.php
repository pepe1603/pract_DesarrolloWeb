<?php
include('conexion.php');
/*
$p_nom = $_POST['txtNombreFull'];
$p_fecha = $_POST['txtFechaNac'];
$p_edad = $_POST['txtEdad'];
$p_escolaridad = $_POST['txtEscolaridad'];
$p_promedio = $_POST['txtPromedio'];
$p_municipio = $_POST['txtPunicipio'];
$p_certificado = $_POST['txtCertificado'];
$p_cfoto = $_POST['txtFoto'];
*/

$p_nom = $_POST['nombre'];
$p_fecha = $_POST['nacimiento'];
$p_edad = $_POST['edad'];
$p_escolaridad = $_POST['escolaridad'];
$p_promedio = $_POST['promedio'];
$p_municipio = $_POST['municipio'];
$p_certificado = $_POST['checkbox'];
$p_fotoURL = $_POST['fotoURL'];


$con = conectarbd();
//$sql="insert into t_productos values (".$par1.",'".$par2."',".$par3.",'".$par4."')";
$sql = "INSERT INTO t_aspirantes (namefull, fecha_nac, edad, eschool, promedio, municipio, certificado, foto) 
                                VALUES ('$p_nom', '$p_fecha', '$p_edad', '$p_escolaridad', '$p_promedio', '$p_municipio', '$p_certificado', '$p_fotoURL');";
//$sql ="insert into td_productos values(".$par1.",'".$par2."',".$par3.",'".$par4.'")";

$respuesta = mysqli_query($con,$sql);



 
?>
